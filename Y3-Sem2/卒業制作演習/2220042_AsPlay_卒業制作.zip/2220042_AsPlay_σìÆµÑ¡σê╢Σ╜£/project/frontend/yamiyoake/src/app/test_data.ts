export const testData = [
    {
        post_id: "1",
        user_id: "1",
        show_id: "1",
        title: "post 1",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "2",
        user_id: "2",
        show_id: "2",
        title: "post 2",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 2,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "3",
        user_id: "3",
        show_id: "3",
        title: "post 3",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 3,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "4",
        user_id: "4",
        show_id: "4",
        title: "post 4",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 4,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "5",
        user_id: "5",
        show_id: "2",
        title: "post 5",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "6",
        user_id: "6",
        show_id: "3",
        title: "post 6",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "7",
        user_id: "7",
        show_id: "2",
        title: "post 7",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "8",
        user_id: "8",
        show_id: "3",
        title: "post 8",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "9",
        user_id: "9",
        show_id: "4",
        title: "post 9",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 2,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "10",
        user_id: "1",
        show_id: "1",
        title: "post 1",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "11",
        user_id: "1",
        show_id: "1",
        title: "post 1",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "12",
        user_id: "1",
        show_id: "1",
        title: "post 1",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "13",
        user_id: "1",
        show_id: "1",
        title: "post 1",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },
    {
        post_id: "14",
        user_id: "1",
        show_id: "1",
        title: "post 1",
        content: "これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。ここに入力内容が表示されます。これはサンプルです。",
        reaction: 1,
        feel: "good",
        is_sensitive: false,
        status: "god",
        created_at: "2024-12-12",
        update_at: "2024-12-13"

    },


];
export const comments = [
    {
        comment_id: "1",
        user_id: "1",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "2",
        user_id: "1",
        post_id: "7",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "3",
        user_id: "1",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "4",
        user_id: "1",
        post_id: "2",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "5",
        user_id: "1",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "6",
        user_id: "1",
        post_id: "5",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "7",
        user_id: "1",
        post_id: "3",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "8",
        user_id: "1",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "9",
        user_id: "1",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "10",
        user_id: "1",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "11",
        user_id: "1",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "12",
        user_id: "1",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "13",
        user_id: "2",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "14",
        user_id: "3",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "15",
        user_id: "4",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "16",
        user_id: "5",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "17",
        user_id: "3",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "18",
        user_id: "2",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },
    {
        comment_id: "19",
        user_id: "1",
        post_id: "1",
        status: "good",
        is_public: true,
        comments: "comment",
        reaction: 1,
        is_censored: true,
        created_at: "2024-12-12",
        update_at: "2024-12-12"
    },

];

export const users = [
    {
        user_id: "1",
        username: "test_user1",
        email: "test@gmail.com",
        birth: "2000-12-12",
        gender: "male",
        is_pricacy: true,
        disease: "風邪",
        condition: "最悪",
        hashpassword: "asiu23e92hjbsidjaihf",
        certification: "ok",
        reset_password_at: "2020-12-12",
        created_at: "2020-12-12",
        update_at: "2020-12-12"
    },
    {
        user_id: "2",
        username: "test_user2",
        email: "test@gmail.com",
        birth: "1955-12-12",
        gender: "female",
        is_pricacy: false,
        disease: "風邪",
        condition: "最悪",
        hashpassword: "asiu23e92hjbsidjaihf",
        certification: "ok",
        reset_password_at: "2020-12-12",
        created_at: "2020-12-12",
        update_at: "2020-12-12"
    }
];

export const bookmarks = [
    {
        post_id: "2",
        user_id: "1",
        created_at: "2020-1-12"
    },
    {
        post_id: "3",
        user_id: "1",
        created_at: "2020-1-12"
    },
    {
        post_id: "4",
        user_id: "1",
        created_at: "2020-1-12"
    },
    {
        post_id: "5",
        user_id: "1",
        created_at: "2020-1-12"
    },
];
export const draft = [{ "type": "paragraph", "children": [{ "color": "#fb923c", "fontsize": "32", "text": "頭痛", "bold": true }, { "color": "#000000", "fontsize": "16", "bold": true, "text": "が痛い" }] }];


export const notification = [
    {
        user_id: 1,
        content: "いいね",
        icon: "as",
        is_Read: false,
        created_at: 2022 - 12 - 12
    },
    {
        user_id: 1,
        content: "リアクション",
        icon: "as",
        is_Read: false,
        created_at: 2022 - 12 - 12
    },
    {
        user_id: 1,
        content: "コメント表示",
        icon: "as",
        is_Read: false,
        created_at: 2022 - 12 - 12
    },
    {
        user_id: 1,
        content: "通知",
        icon: "as",
        is_Read: true,
        created_at: 2022 - 12 - 12
    },
    {
        user_id: 1,
        content: "通知",
        icon: "as",
        is_Read: true,
        created_at: 2022 - 12 - 12
    },
    {
        user_id: 1,
        content: "通知",
        icon: "as",
        is_Read: true,
        created_at: 2022 - 12 - 12
    },
    {
        user_id: 1,
        content: "通知",
        icon: "as",
        is_Read: false,
        created_at: 2022 - 12 - 12
    },
    {
        user_id: 1,
        content: "通知",
        icon: "as",
        is_Read: false,
        created_at: 2022 - 12 - 12
    },
];
