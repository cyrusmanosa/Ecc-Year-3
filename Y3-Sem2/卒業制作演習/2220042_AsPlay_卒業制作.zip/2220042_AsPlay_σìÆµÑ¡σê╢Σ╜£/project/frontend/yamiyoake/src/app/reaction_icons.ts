import good from "@/app/img/reactions/good.png";
import good_color from "@/app/img/reactions/good_color.png";
import dogeza from "@/app/img/reactions/dogeza.png";
import dogeza_color from "@/app/img/reactions/dogeza_color.png";
import gassyou from "@/app/img/reactions/gassyou.png";
import gassyou_color from "@/app/img/reactions/gassyou_color.png";
import heart from "@/app/img/reactions/heart.png";
import heart_color from "@/app/img/reactions/heart_color.png";

export const white_reaction_icons = [dogeza,gassyou,good,heart];
export const color_reaction_icons = [dogeza_color,gassyou_color,good_color,heart_color];