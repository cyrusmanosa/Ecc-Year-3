const Header = () =>{
    return(
        <hr className="header bg-[#B8A193] object-cover w-full h-[7%]  " />
    );
}
export {Header};

