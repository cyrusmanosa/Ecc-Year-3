DROP TABLE IF EXISTS "posts_reaction";
DROP TABLE IF EXISTS "comments_reaction";