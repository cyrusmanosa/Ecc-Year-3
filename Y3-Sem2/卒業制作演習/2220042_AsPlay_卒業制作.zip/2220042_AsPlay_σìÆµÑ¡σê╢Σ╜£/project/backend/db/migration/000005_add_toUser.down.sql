ALTER TABLE comments
DROP COLUMN post_user;