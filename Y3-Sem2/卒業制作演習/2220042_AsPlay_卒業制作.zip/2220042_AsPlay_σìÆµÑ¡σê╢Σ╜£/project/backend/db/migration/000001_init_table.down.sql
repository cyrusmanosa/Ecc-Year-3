DROP TABLE IF EXISTS "token";

DROP TABLE IF EXISTS "tag";

DROP TABLE IF EXISTS "blockuser";

DROP TABLE IF EXISTS "bookmarks";

DROP TABLE IF EXISTS "comments";

DROP TABLE IF EXISTS "posts";

DROP TABLE IF EXISTS "adminuser";

DROP TABLE IF EXISTS "searchrecord";

DROP TABLE IF EXISTS "users";