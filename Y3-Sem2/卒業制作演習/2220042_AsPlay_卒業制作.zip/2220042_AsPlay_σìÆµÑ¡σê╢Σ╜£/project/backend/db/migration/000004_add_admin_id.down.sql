ALTER TABLE adminuser
DROP COLUMN admin_id;